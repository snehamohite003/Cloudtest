package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

/**
 * Page Object Model for Login Page
 * URL: https://cloudtestmanager.soasta.com/concerto/Login?goto=Central
 */
public class LoginPage extends BasePage {

    // ============== Web Elements ==============

    @FindBy(id = "username")
    private WebElement usernameField;

    @FindBy(id = "password")
    private WebElement passwordField;

    @FindBy(id = "loginButton")
    private WebElement loginButton;

    @FindBy(css = ".error-message, .login-error, #errorMessage")
    private WebElement errorMessage;

    @FindBy(css = ".validation-message, .field-error")
    private WebElement validationMessage;

    @FindBy(css = ".dashboard, #central, .central-dashboard")
    private WebElement dashboardElement;

    // ============== Constructor ==============

    public LoginPage(WebDriver driver) {
        super(driver);
    }

    // ============== Page Actions ==============

    /**
     * Enter username in the username field
     */
    public LoginPage enterUsername(String username) {
        clearAndType(usernameField, username);
        return this;
    }

    /**
     * Enter password in the password field
     */
    public LoginPage enterPassword(String password) {
        clearAndType(passwordField, password);
        return this;
    }

    /**
     * Click on Login button
     */
    public LoginPage clickLoginButton() {
        clickElement(loginButton);
        return this;
    }

    /**
     * Perform complete login action
     */
    public LoginPage login(String username, String password) {
        enterUsername(username);
        enterPassword(password);
        clickLoginButton();
        return this;
    }

    // ============== Verification Methods ==============

    /**
     * Check if login was successful by verifying dashboard is displayed
     */
    public boolean isLoginSuccessful() {
        try {
            wait.until(ExpectedConditions.visibilityOf(dashboardElement));
            return dashboardElement.isDisplayed();
        } catch (Exception e) {
            // Alternative check - verify URL changed from login page
            return !driver.getCurrentUrl().contains("Login");
        }
    }

    /**
     * Get error message text
     */
    public String getErrorMessage() {
        try {
            wait.until(ExpectedConditions.visibilityOf(errorMessage));
            return errorMessage.getText();
        } catch (Exception e) {
            return "";
        }
    }

    /**
     * Check if error message is displayed
     */
    public boolean isErrorMessageDisplayed() {
        try {
            wait.until(ExpectedConditions.visibilityOf(errorMessage));
            return errorMessage.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Check if validation message is displayed
     */
    public boolean isValidationMessageDisplayed() {
        try {
            wait.until(ExpectedConditions.visibilityOf(validationMessage));
            return validationMessage.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Get the current page title
     */
    public String getPageTitle() {
        return driver.getTitle();
    }

    /**
     * Get current URL
     */
    public String getCurrentUrl() {
        return driver.getCurrentUrl();
    }

    /**
     * Check if login page is displayed
     */
    public boolean isLoginPageDisplayed() {
        try {
            return usernameField.isDisplayed() && passwordField.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }
}
