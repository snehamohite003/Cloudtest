package runners;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = "src/test/resources/features",
        glue = {"stepdefinitions", "hooks"},
        plugin = {
                "pretty",
                "html:reports/cucumber-html-report.html",
                "json:reports/cucumber-report.json",
                "junit:reports/cucumber-report.xml"
        },
        monochrome = true,
        dryRun = false,
        tags = "@Login"
)
public class TestRunner {
}
